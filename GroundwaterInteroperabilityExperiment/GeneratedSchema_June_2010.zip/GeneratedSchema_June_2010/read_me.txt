For sake of validation of instance documents, I copied most recent copies of OM2 and related schemas into temp_2.0_schemas directory.
Those schemas should be soon posted to public OGC site (as of June 18 2010).  When this is done, WaterML2.0 schemas should be modified to point to the public location (http://schemas.opengis.net)

Note: I did not changed the schematron files, just the xsd.
  While your document might validate with XSD, it might not be totally conformant.
  I fixed some of the OM2 schemas so they find each other using relative path. The original version where using full path to (non-existing) http://schemas.opengis.net/...
  I made the same kind of adjustements to WaterML schemas.
  
  If you have any question (for example, if I broke something), feel free to contact me.
  
================================================================
Eric Boisvert
Sp�cialiste TI-GI / IT-IM specialist

Laboratoire de cartographie num�rique et de photogramm�trie (LCNP)
Digital Cartography and Photogrammetry Laboratory (DCPL)
Commission g�ologique du Canada (Qu�bec) / Geological Survey of Canada (Quebec)
Ressources naturelles Canada / Natural Resources Canada
Gouvernement du Canada / Government of Canada
  


